import math

def myabs(x):
    return math.fabs(x)

# class something(object):
#     def __init__(self):
#         print("Hello world: init")

#     def hello(self):
#         print("Hello world: hello")

#     def myabs(x):
#         return math.fabs(x)