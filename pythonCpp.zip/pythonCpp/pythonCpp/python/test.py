import math

def myabs(x):
    return math.fabs(x)